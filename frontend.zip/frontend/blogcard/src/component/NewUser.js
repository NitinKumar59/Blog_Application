import React from "react";

function NewUser() {
  return <div>NewUser</div>;
}

export default NewUser;
