import { useEffect,useState } from "react"
import React from 'react'
import axios from "axios"

function Home() {
  const [datas,setDatas]=useState();
  const sendRequest=async()=>{
    const res =await axios.get("apiurl").catch(err=>console.log(err));
    const data=res.data;
    return data;
  }
  useEffect(()=>{
    sendRequest().then(data=>setDatas(data.blogs));
  },[])
  return (
    <div></div>
  )
}

export default Home