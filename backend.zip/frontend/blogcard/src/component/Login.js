import React from "react";
import { Box, Button, TextField, Typography } from "@mui/material";
import { useState } from "react";
import axios from "axios";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { authActions } from "./store";
function Login() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [inputs, setInputs] = useState({
    name: "",
    email: "",
    password: "",
  });
  const [isSignup, setSignup] = useState(false);
  const handlechange = (e) => {
    setInputs((preState) => ({
      ...preState,
      [e.target.name]: e.target.value,
    }));
  };
  const sendRequest = async (type = "login") => {
    const res = await axios
      .post(`http://localhost:5000/${type}`, {
        name: inputs.name,
        email: inputs.email,
        password: inputs.password,
      })
      .catch((err) => console.log(err));
    const data = await res.data;
    return data;
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(inputs);
    if (isSignup) {
      sendRequest("signup")
        .then(() => dispatch(authActions.login()))
        .then(() => navigate("/"))
        .then((data) => console.log(data));
    } else {
      sendRequest()
        .then(() => dispatch(authActions.login()))
        .then(() => navigate("/"))
        .then((data) => console.log(data));
    }
  };
  return (
    <div>
      <form onSubmit={handleSubmit}>
        <Box
          maxWidth={400}
          display="flex"
          padding={2}
          flexDirection={"column"}
          alignItems={"center"}
          justifyContent={"center"}
          boxShadow="5px 10px 30px GRAY"
          margin={"auto"}
          marginTop={5}
          borderRadius={5}
        >
          <Typography variant="h3" color="secondary">
            {!isSignup ? "Login" : "Signup"}
          </Typography>
          {isSignup && (
            <>
              {" "}
              <TextField
                name="name"
                onChange={handlechange}
                margin="normal"
                placeholder="Enter Name"
                autoComplete="off"
                values={inputs.name}
              />
            </>
          )}

          <TextField
            name="email"
            onChange={handlechange}
            values={inputs.email}
            type={"email"}
            placeholder="Enter Email"
            margin="normal"
            autoComplete="off"
          />
          <TextField
            name="password"
            onChange={handlechange}
            type={"password"}
            placeholder="Password"
            margin="normal"
            autoComplete="off"
            values={inputs.password}
          />
          {/* <TextField/>
          <TextField/>
          <TextField/> */}
          <Button
            type="submit"
            variant="conteined"
            sx={{ borderRadius: 3, background: "#42C2FF" }}
            color="secondary"
          >
            Submit
          </Button>
          <br />
          <Button
            marginTop={"2px"}
            onClick={() => setSignup(!isSignup)}
            variant="conteined"
            sx={{ borderRadius: 3 }}
            color="primary"
          >
            Change To {isSignup ? "Login" : "Signup"}
          </Button>
        </Box>
      </form>
    </div>
  );
}

export default Login;
