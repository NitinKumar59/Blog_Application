import React from "react";
import { useState } from "react";
import {
  BrowserRoute,
  NavLink,
  Link,
  Route,
  Routes,
  BrowserRouter,
} from "react-router-dom";
import {
  AppBar,
  Typography,
  Toolbar,
  Box,
  Button,
  Tabs,
  Tab,
} from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { authActions } from "./store";
function Header() {
  const dispatch = useDispatch();
  const isLoggedIn = useSelector((state) => state.isLoggedIn);
  const [tabValue, setTabValue] = useState();
  return (
    <AppBar
      position="sticky"
      sx={{
        background:
          "linear-gradient(90deg, rgba(131,58,180,1) 0%, rgba(69,165,252,1) 100%)",
      }}
    >
      <Toolbar>
        <Typography variant="h4">RectCard</Typography>
        {isLoggedIn && (
          <>
            {" "}
            <Box
              variant="contained"
              marginLeft={"auto"}
              marginRight={"auto"}
              display="flex"
            >
              <Tabs
                textColor="inherit"
                value={tabValue}
                onChange={(e, tabValue) => setTabValue(tabValue)}
              >
                <Tab LinkComponent={Link} to="/" label="Home" />
                <Tab LinkComponent={Link} to="/contact" label="Contact" />
                <Tab LinkComponent={Link} to="/about" label="About" />
                <Tab LinkComponent={Link} to="/" label="Nitin" />
              </Tabs>
            </Box>
          </>
        )}
        <Box display="flex" marginLeft="auto">
          {!isLoggedIn && (
            <>
              <Button
                LinkComponent={Link}
                to="/login"
                light="dark"
                variant="conteined"
                sx={{ background: "#FA016D", margin: 0.6, borderRadius: 8 }}
              >
                Login
              </Button>
              <Button
                variant="conteined"
                LinkComponent={Link}
                to="/login"
                sx={{ background: "#0E5CAD", margin: 0.6, borderRadius: 8 }}
              >
                New Register
              </Button>
            </>
          )}
          {isLoggedIn && (
            <>
              <Button
                LinkComponent={Link}
                to="/login"
                onClick={() => dispatch(authActions.logout())}
                variant="conteined"
                sx={{ background: "#BC78EC", margin: 0.6, borderRadius: 8 }}
                color="warning"
              >
                LogOut
              </Button>
            </>
          )}
        </Box>
      </Toolbar>
    </AppBar>
  );
}

export default Header;
