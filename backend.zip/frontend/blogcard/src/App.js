import React from "react";
import { Route, Routes } from "react-router-dom";
import Contact from "./component/Contact";
// import "./App.css";

import Header from "./component/Header";
import Home from "./component/Home";
import About from "./component/About";
// import Contact from "./component/Contact";
import Login from "./component/Login";
import Contact1 from "./component/Contact";
import NewUser from "./component/NewUser";
// import {useSelector}from 'react-redux'

function App() {
  // const isLoggedIn=useSelector(state=>state.isLoggedIn);
  // console.log(isLoggedIn)
  return (
    <div>
      <React.Fragment>
        <header>
          <Header />
        </header>
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="contact" element={<Contact1 />} />
            <Route path="about" element={<About />} />
            <Route path="login" element={<Login />} />
            <Route path="/newregistration" element={<NewUser />} />
          </Routes>
        </main>
      </React.Fragment>
    </div>
  );
}

export default App;
